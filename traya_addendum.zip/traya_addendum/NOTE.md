# Smarter calls, not more calls
### Traya · AI/ML Lead take-home · written note

This is the narrative companion to `traya_call_prioritisation.ipynb` (evidence) and `traya_call_prioritisation_deck.pptx` (the 60-minute walkthrough). Every number here comes from a cell in the notebook.

---

## 1 · Problem framing

**What the system optimises.** The brief reads like a churn-prediction problem; it is a *constrained, causal allocation* problem. Every morning there are more callable customers than coach-hours, and the question is not "who will churn?" but "for whom does a call today change the outcome?" So the ranking quantity is

```
priority = uplift(call) × P(connect) × value(order_number) × kit_value/3000
```

followed by a top-K selection **per language × gender coach pool**, with customer- and coach-booked slots bypassing the ranking exactly as they do today.

- **uplift(call)** — the incremental effect on the 60-day reorder. Until an experiment exists this is a proxy: an inverted-U in churn risk, on the assumption that near-certain stayers and near-certain leavers respond least to a call. The nine-month deliverable replaces this proxy with a CATE model estimated on experiment data.
- **P(connect)** — reachability per (customer, call type, attempt). Its job is to stop spending third attempts (connect rate 35%) on people who never pick up.
- **value(order_number)** — how much of the remaining path to O6 this reorder unlocks: `1/(6 − n) + 0.25`. You asked for O5/O6 as the north star; this is how it enters without making the label itself "reaches O6" (only ~1,400 customers have, which is too thin to train on). The label stays "next order within 60 days"; the *weight* encodes the destination.

**What it deliberately does not optimise.**
- Connect rate or call volume: trivially inflatable, uncorrelated with retention in this data.
- Coach `outcome_tag`: it's a sentiment note, not an effect measure (see §2). Make it a KPI and it will be gamed within a quarter.
- Raw churn probability: ranking by risk alone sends coaches to lost causes and to customers who would have reordered anyway.

**What "good" looks like a year in.** Fewer total outbound calls; equal or better O(n)→O(n+1) within every order cohort; a holdout arm that tells us how much of retention calls actually cause; reason codes coaches trust enough to argue with; and the rules engine still running, as the fallback nobody has needed for months.

---

## 2 · The data, honestly

The data is cleaner than the brief implies — no orphan keys, no negative durations, 100% coach-compatibility compliance, zero missing diagnosis fields. The mess is concentrated in five places. Two of them would silently break a naive model.

1. **`outcomes.csv` is right-censored in a way that leaks.** Rows are only kept when the 60-day answer is determinable. For orders in the final 60 days before the snapshot, that means "only the customers who already reordered" — reorder rate 98–100% for Oct–Nov 2025. A model trained on it learns *recent ⇒ loyal*. Fix: drop rows with `current_order_date > snapshot − 60d`. 20,723 labelled decisions remain, base reorder rate 64.4%.
2. **A 22% call-volume dip in the weeks of 19 Oct–1 Nov 2025** (Diwali), across every call type, with connect rate unchanged. The team was short, not the customers unreachable. This is the dataset's one natural experiment (§4).
3. **Call timestamps are not customer-local.** 23% of attempts are stamped 00:00–05:59 vs 3% of app events, and connect rate is flat across all 24 hours. Hour-of-day is unusable until the dialler clock is fixed — my first question to the CRM team.
4. **`outcome_tag` is near-random.** The tag mix is identical across all nine call types to two decimals, and the last tag on an order barely separates reorderers (negative 59%, positive 66%). Useful as a weak feature; useless as a target.
5. **Ticket presence is the strongest signal; ticket text is noise.** Any ticket around the order: reorder 73% → 50% (one) → 24% (two+). High/urgent severity: 66% → 38%. But `agent_notes_short` has 24 templated values and every one sits at ~35% reorder — "GST invoice request" churns exactly like "Refund request". Count and severity go in the model; there is no NLP value in the notes as they stand. Separately: tickets per order jumped from 0.50 to 0.84 in Nov 2025 with 200 still open. Something broke, and censoring hides its retention cost for another two months.

**Signals I trust.** Engagement in the first 14 days after delivery (reorder 54% → 74% across quartiles), especially medicine logs and WhatsApp clicks; `app_session_short` (1–5 s sessions) as a *negative*; ticket count and severity; diagnosed severity (severe 74%, moderate 65%, mild 55% — the worse the hair, the more motivated the customer); order number.

**Signals I threw out.** Stress, sleep and nutrition scores (ρ ≈ 0.00 with outcome); scalp condition; region; channel; language; hour-of-day; ticket text.

**Things I'd ask a coach before trusting.** Why genetic root-cause reorders least (58%) — expectation-setting? Why 55+ churns more (56%) — app friction? Why 1,911 rescheduled slots never link to a call — CRM gap or real drop-out? Why retention *declines* past O10 — graduation or drift?

**Operational facts the optimiser must respect.** Connect decays 78% → 61% → 35% across attempts. Hindi is 43% of customers with 43 of 220 coaches; Kannada is 3% with 45 coaches; calls per coach range 6 to 5,571. Matching compliance is perfect, so the mismatch shows up as load skew rather than violations — capacity is a per-pool constraint, never a global one. And the current policy puts the most calls on O2 (6.1 per order), more than O1, because RR1/RR2 stack on the standard sequence.

---

## 3 · Approach

**Decision grain.** One row per (customer, order), scored at *delivery + 7 days* — the W1 moment, when the first real adherence signal exists and the Retention/RR sequence hasn't started. Every feature is computed from data strictly before that timestamp. In production this is a daily-refreshed Feature Store table keyed by (customer_id, as_of_date), and the same code runs for every customer every morning.

**Risk model.** Gradient-boosted trees (HistGradientBoosting locally, LightGBM on Databricks). Time split: train on decisions before 1 Jun 2025, validate on Jun–Sep (8,014 rows). AUC 0.72 vs **0.67 for the rules-engine proxy** (rank by order number) and 0.63 for engagement alone. Top decile churns 72%, bottom decile 10%, base 33%. Top features: active days in the last 30, lifetime tickets, tickets in the last 30 days, severity, tenure.

That 0.67 is the honest headline: order number already captures most of the risk, which is why the rules engine isn't terrible. The model's edge is *within* an order cohort — which of this week's O1s is actually at risk.

**Reachability model.** P(connect) per attempt from call type, attempt number, order number, language, weekday and the customer's prior connect rate (Bayesian-smoothed, strictly earlier attempts). AUC 0.66 vs 0.64 for attempt-number alone. Reachability is mostly attempt decay; the customer history adds a little.

**Backtest against the rules engine.** For each day in the validation window the candidate pool is everyone whose decision point falls that day; each policy picks the top 50%. Share of O6-weighted churners reached: random 0.50, rules 0.53, risk-only 0.64, **priority score 0.63 — +19% over rules**. The gap widens as capacity tightens (0.28 vs 0.20 at 20% capacity) and vanishes when capacity is unconstrained — which is also the answer to "what if capacity tripled?": you then optimise who *not* to call, timing, and content, not ordering.

**Why not the obvious alternatives.** Sequence/deep models: 20k labelled rows, tabular, and coaches need reason codes. Pure uplift modelling now: there is no randomisation in the logs to learn from. An LLM in the ranking path: there is no free text worth reading, and latency/auditability get worse for nothing.

---

## 4 · Measurement

Everything in §3 is *targeting* quality: does the ranking put future churners on top? It says nothing about whether calling them changes anything. Two pieces of evidence say the causal effect of the marginal call is small and cannot be estimated from these logs:

- Connected calls correlate with reorder (59% → 71%), but calls are assigned by order number and order number predicts reorder — policy confounding.
- Orders placed 15–30 Sep 2025 had their Retention/RR windows fall in the Diwali dip and received ~6% fewer calls than the Aug cohort. Their reorder rate was *not lower* (O1 52.7% vs 48.0%; O2 62.6% vs 67.2%; O3 78.7% vs 71.0% — noise around zero).

So the launch is an experiment, not a rollout.

- **Randomise at the customer level** (hash of `customer_id`), stratified by order number, into rules (45%) / model (50%) / **no-outbound-call holdout (5%)**. Slots and inbound are honoured in every arm. Without the holdout there is no uplift estimate, only correlation.
- **Primary metric:** O(n)→O(n+1) reorder within 60 days per arm, stratified by order number. **Efficiency metric:** incremental reorders per coach-hour. Guardrails: connect rate, complaint tickets, coach CSAT.
- **Six-month verdict:** model beats rules on reorders per coach-hour with a CI excluding zero, *and* the holdout tells us how much retention calls cause at all. Then the experiment data replaces `uplift_proxy` with a learned CATE model (T-learner or causal forest) — the nine-month deliverable.

Power, roughly: with ~2,000 new orders a month and a 33% churn base, a 3-point absolute lift in the model arm vs rules is detectable at 80% power within ~3 months at 50/45 split. The holdout is too small to detect small call effects on its own; its purpose is to bound the *total* effect of calling, which is the number the business has never had.

---

## 5 · System view (Databricks only)

Editable diagram: Lucidchart (link in README); static copy in `architecture.png`.

- **Ingest.** Lakeflow Connect / Auto Loader into Bronze Delta: CRM/dialler (calls, slots), app/WhatsApp/IVR events (streaming), orders, tickets, diagnosis, roster.
- **Silver — decision grain.** One row per (customer, order, as_of_date); as-of joins; timezone normalisation; dedupe; the censoring rule lives here so no downstream job can forget it.
- **Gold — Feature Store (Unity Catalog).** Engagement windows, ticket load, call history, slots, diagnosis, and coach capacity by language × gender. Lakehouse Monitoring on drift, label delay and volume.
- **ML platform — MLflow.** Experiments for risk, reachability and (later) uplift, each logged against a versioned eval dataset in Delta with the rules-proxy baseline as a tracked metric. Unity Catalog model registry with champion/challenger aliases and lineage to features. Weekly retrain job.
- **Daily decision job, 05:00 IST.** Batch score → priority → optimiser (top-K per pool, attempt-3 suppression, do-not-call list) → arm assignment → `daily_call_queue` Delta with reason codes → CRM sync by 06:30 via Delta Sharing or REST. Coaches start at 09:00. Budget ≤ 20 minutes for ~50k candidates.
- **Kill switch.** If the job is late, monitoring fires, or connect rate drops, the CRM receives yesterday's rules-engine queue — never an empty one.
- **GenAI at the last mile only.** Mosaic AI Gateway fronts the LLM (rate limits, PII guardrails, usage logs). A LangGraph "call brief" agent pulls the customer's features, open tickets and last call and produces five lines for the coach, on demand when the card opens, cached per customer-day, < 3 s. Every prompt change is gated by an MLflow GenAI evaluation (faithfulness, no unstated clinical claims) on a golden set of ~200 briefs reviewed by senior coaches. See `src/call_brief_agent.py`.
- **Feedback loop.** Every attempt, connect, tag and reorder lands back in Bronze the next morning.

**Failure modes, ranked by fear.**
1. Silent label leakage (censoring or timezone drift) makes the model look great while quietly starving O3–O5 customers → censoring rule in Silver, as-of joins, holdout arm.
2. The optimiser concentrates load on Hindi coaches → per-pool capacity is a hard constraint.
3. Coaches learn to game `outcome_tag` if it becomes a KPI → it is a feature, never a target.
4. Job lateness → kill switch to yesterday's rules queue.
5. The brief hallucinates a clinical fact → faithfulness eval gate; medical advice out of scope.

---

## 6 · Leading the team

Three engineers (a fourth would take the GenAI brief and the dashboard).

- **Eng A — data foundation.** Silver decision-grain table, as-of joins, censoring rule, Feature Store, timezone fix with CRM, backtest harness. Ships first; everyone else depends on it.
- **Eng B — models.** Risk and reachability in MLflow with the rules-proxy baseline as a first-class metric; weekly retrain; reason codes. Later: CATE on experiment data.
- **Eng C — decision job and integration.** Optimiser with per-pool capacity, arm assignment, `daily_call_queue`, CRM sync, kill switch, AI/BI dashboard. Owns shadow mode.

**First three months.** Month 1: shadow mode — the model queue is written next to the rules queue and nothing is acted on; the data traps are fixed. Month 2: experiment live on 20% of customers, holdout included, dashboard up. Month 3: 100%; first read of reorders per coach-hour; attempt-3 suppression switched on. Months 4–9: CATE model, call-brief agent, per-call-type timing, content tests.

**What I'd tell them not to do.** Build uplift models before the experiment exists. Chase AUC. Touch coach-matching logic in v1. Put an LLM in the ranking path. Make `outcome_tag` a KPI.

---

## 7 · What I'd want to know that you didn't tell me

- Capacity, really: calls per coach per day by language; whether coaches pick from the queue or take the next item; whether the queue re-sorts intra-day.
- The dialler clock: are attempt timestamps UTC or system-generated?
- What a coach can actually change on a call — discounts, kit swaps, doctor escalation. The lever set defines what "uplift" can mean.
- November: what drove tickets per order from 0.50 to 0.84, and is it still happening?
- Rescheduled slots: why do 1,911 of them never link to a call?
- The tail: retention declines past O10 — graduation or drift? It decides whether O6+ customers belong in this queue at all.

**Hypotheticals I'm ready for.** *Capacity triples:* ordering stops mattering (the backtest shows the gap closing above ~90% coverage); the problem becomes who *not* to call, timing, and message content — and the holdout becomes the most valuable arm. *App-open data disappears tomorrow:* tickets, order history and diagnosis carry most of the risk signal (engagement-only AUC is 0.63; the full model without engagement would sit around the rules proxy); the label and the experiment don't change at all.

---

## 5a · Medallion layers, concretely

Bronze is deliberately *not* cleaned: it is the append-only, schema-evolving copy of each source that lets us replay history when a rule changes (the timezone fix will be the first such replay). Cleanup and data quality live in the Bronze→Silver transform as Lakeflow Declarative Pipeline expectations, so every violation is counted, quarantined and visible rather than silently coerced. Feature engineering lives in Gold. Raw → validated → features.

**Bronze — land it, don't touch it.** Lakeflow Connect for CRM tables (calls, slots) incremental on `attempt_time`; Auto Loader streaming for engagement events; daily CDC snapshots for orders, customers, tickets, diagnosis, roster. Every row carries `_ingest_ts`, `_source_file`, `_batch_id`. Call timestamps keep a `_source_tz` column so the UTC question stays answerable. Duplicate events are kept — dedupe is a Silver decision.

**Silver — every EDA finding becomes an expectation.**

| Silver table | Transform | Expectation | Traces to |
|---|---|---|---|
| `silver.orders` | Types; recompute `days_since_prev_order` | `expect_or_fail(delivery_date >= order_date)`; `expect(order_number contiguous per customer)`; `expect(14 <= gap <= 90)` warn | Guards for the future (zero violations today) |
| `silver.outcomes` | **Censoring rule here:** `label_observable = order_date <= run_date − 60d`; unobservable rows kept with `label = NULL` | `expect_or_fail(label IS NULL WHEN NOT observable)` | Trap 1 — the leak |
| `silver.call_attempts` | Normalise to customer-local time once CRM confirms source tz; `is_connected`, `is_final_attempt` | `expect(duration = 0 WHEN status != 'connected')`; `expect(outcome_tag IS NULL WHEN status != 'connected')`; `expect(coach–customer language ∩ ≠ ∅ AND gender compatible)` → alert if compliance < 100% | Trap 3; compatibility fact |
| `silver.engagement_events` | Dedupe on `(customer, ts, type)`; `expect_or_drop(ts >= signup_date)` | Table-level `expect(share of events 00–05h < 5%)` as a drift check | 61 dups; tz sanity |
| `silver.tickets` | `opened_at` flagged date-precision; enums enforced | `expect_or_drop(category IN enum)`; `expect(open backlog < 1.5 × 30d median)` → alert — would have caught November in week one | Trap 5; Nov spike |
| `silver.slot_bookings` | — | `expect(linked_call_id IS NOT NULL WHEN status = 'completed')` — 92% today; the 8% are quarantined for CRM follow-up | Rescheduled-slot gap |
| `silver.coaches` | Active roster; **capacity by language × gender** derived here as a fact table | `expect_or_fail(languages non-empty)` | Hindi 43/220 |

Two things are quarantined rather than fixed: unlinked completed slots and any compatibility violation. Fixing them silently is how the load-skew problem becomes invisible.

**Gold — features, point-in-time correct.** `gold.decision_features` (one row per customer × order × as_of_date, as-of joins only), `gold.coach_capacity_daily`, `gold.reach_features`, `gold.eval_datasets` (versioned). Gold-level DQ: null-rate ceiling per window feature (a jump means a feed silently stopped) and a weekly distribution check on `p_churn` by order number (Lakehouse Monitoring → kill switch). Sketch: `src/pipelines/silver_expectations.py`, `src/pipelines/gold_features.py`.

## 5b · Feature engineering

**Principles.**
1. *Point-in-time or nothing.* Every feature is computed from rows with timestamp `< as_of_date`. Training uses the Feature Store's `timestamp_lookup_key` so the as-of join is the framework's job, not a hand-written filter that someone forgets. Daily scoring calls the same lookup — one code path, no train/serve skew.
2. *Programme clock, not calendar clock.* Windows are anchored to `days_since_delivery`, because W1 at day 7 means the same thing for every customer while "last Tuesday" does not.
3. *Rates over counts where exposure varies.* `conn_rate_hist` is Bayesian-smoothed toward the global 0.72 with a prior weight of three calls, so an O1 customer with one missed call isn't scored as unreachable.
4. *Negative signals are first-class.* `app_session_short` (1–5 s sessions) is a disengagement feature, not noise to be summed into "engagement".
5. *Nothing derived from the target, nothing from the future, nothing we can't reproduce at 05:00.* No hour-of-day until the clock is fixed; no ticket text; no `outcome_tag` from the current order's calls placed after the decision point.

**Feature catalogue (58 features, all implemented in `src/pipeline.py`).**

| Family | Features | Window | Why |
|---|---|---|---|
| Programme position | `order_number`, `tenure_days`, `delivery_lag`, `kit_value_inr`, `kit_value_drop`, `prev_gap`, `mean_gap_hist`, `channel` | as-of | Strongest single prior; kit-value drop encodes discounting |
| Engagement — recency/frequency | `ev14_total`, `ev14_med`, `ev14_dur`, per-type counts for 9 event types, `ev30_total`, `ev30_med`, `ev30_active_days`, `days_since_last_ev` | 14d, 30d before decision | #1 family by importance; `ev30_active_days` is the top feature |
| Engagement — negative | `ev14_app_session_short` | 14d | Open-and-close behaviour precedes churn |
| Call history | `calls_hist`, `conn_hist`, `pos_hist`, `neg_hist`, `declined_hist`, `att3_hist`, `calls_90`, `conn_90`, `conn_rate_hist`, `days_since_last_call` | lifetime, 90d | Reachability and "already saturated with calls" |
| Tickets | `tk30`, `tk30_hi`, `tk30_order`, `tk30_medical`, `tk_open`, `tk_life` | 30d, open-now, lifetime | #2 family; `tk_life` and `tk30` are features 2 and 3 |
| Slots | `slot_pending`, `slot_cust_pending`, `slots_hist`, `slots_missed` | pending-now, lifetime | Customer-booked slot = intent; missed slots = friction |
| Diagnosis | `severity`, `root_cause_profile`, `scalp_condition`, `has_diabetes_flag`, `has_thyroid_flag`, `duration_of_loss_years`, `stress/sleep/nutrition_score` | static | `severity` matters (74% vs 55%); the three scores are ρ≈0 and are candidates for removal after one more retrain |
| Demographics | `gender`, `language`, `age_band`, `region` | static | Low importance, kept for fairness monitoring and per-pool capacity, not for lift |

**Reachability features** (separate table, per attempt): `call_type`, `attempt_number`, `order_number_at_call`, `language`, `gender`, `age_band`, `dow`, `prior_calls`, `prior_conn_rate` (strictly earlier attempts). Hour-of-day is the first feature to add once the dialler clock is trusted.

**What I would add in production, in priority order.**
1. *Trend features* — 14d medicine logs vs the previous 14d (a customer slowing down looks different from one who never started). Cheap, likely the biggest single gain.
2. *Running-out clock* — days since delivery vs the kit's nominal duration, and days until the customer's own typical reorder gap. Turns "Retention at day 29" into a customer-specific window.
3. *Per-call-type reach* — connect rate by (customer, call_type) once volumes allow; W0 and customer_slot behave differently from RR2.
4. *Festival/holiday calendar* as a scoring-day feature, because the Diwali dip will recur.
5. *Coach features* — assigned coach's CSAT and tenure — **treated with care**: coach assignment is part of the treatment, so these belong in the uplift model as moderators, not in the risk model as covariates.
6. *WhatsApp response latency* and *push-open-to-app-open conversion* once event linkage exists.

**Governance in Unity Catalog.** Each Gold table has an owner, a refresh SLA (03:30 IST), a null-rate alert, and PII tags on `customer_id`/`language`/`region` so the call-brief agent reads only what it needs. Feature versions are tied to model versions through MLflow lineage, so a champion/challenger comparison always names the feature version it was trained on.

"""Lakeflow Declarative Pipelines (DLT) sketch for the Bronze -> Silver layer.
Every rule here is a finding from the EDA notebook turned into an expectation.
Databricks only; included to show the shape. Table names: traya.bronze.* -> traya.silver.*"""
import dlt
from pyspark.sql import functions as F, Window as W

RUN_DATE = F.current_date()

# ---------------------------------------------------------------- orders
@dlt.table(comment="Orders, typed; gap recomputed; contiguity checked")
@dlt.expect_or_fail("delivery_after_order", "delivery_date >= order_date")
@dlt.expect("plausible_gap", "days_since_prev_order IS NULL OR days_since_prev_order BETWEEN 14 AND 90")
@dlt.expect("contiguous_order_numbers", "order_number = prev_order_number + 1 OR prev_order_number IS NULL")
def orders():
    w = W.partitionBy("customer_id").orderBy("order_number")
    return (dlt.read("bronze_orders")
            .withColumn("prev_order_number", F.lag("order_number").over(w))
            .withColumn("days_since_prev_order", F.datediff("order_date", F.lag("order_date").over(w))))

# ---------------------------------------------------------------- outcomes (the censoring rule lives here)
@dlt.table(comment="Reorder labels; unobservable rows kept with NULL label so nothing downstream can leak")
@dlt.expect_or_fail("no_label_when_unobservable", "label_observable OR next_order_placed_within_60d IS NULL")
def outcomes():
    o = dlt.read("bronze_outcomes")
    observable = F.col("current_order_date") <= F.date_sub(RUN_DATE, 60)
    return (o.withColumn("label_observable", observable)
             .withColumn("next_order_placed_within_60d", F.when(observable, F.col("next_order_placed_within_60d"))))

# ---------------------------------------------------------------- call attempts
@dlt.table(comment="Call attempts in customer-local time, with compatibility check against roster")
@dlt.expect("duration_zero_unless_connected", "status = 'connected' OR duration_seconds = 0")
@dlt.expect("tag_only_when_connected", "status = 'connected' OR outcome_tag IS NULL")
@dlt.expect("coach_customer_compatible", "compat_ok")          # alert if this ever drops below 100%
def call_attempts():
    ch = dlt.read("bronze_call_history")
    cu = dlt.read("bronze_customers").select("customer_id", F.col("gender").alias("cust_gender"), F.col("language").alias("cust_language"))
    co = dlt.read("bronze_coaches").select("coach_id", "gender_handled", F.split("languages", r"\|").alias("coach_langs"))
    return (ch.join(cu, "customer_id", "left").join(co, "coach_id", "left")
              .withColumn("attempt_time_local", F.from_utc_timestamp("attempt_time", "Asia/Kolkata"))   # TODO confirm source tz with CRM
              .withColumn("is_connected", F.col("status") == "connected")
              .withColumn("compat_ok", (F.col("coach_id").isNull()) |
                          (((F.col("gender_handled") == "Both") | (F.col("gender_handled") == F.col("cust_gender")))
                           & F.array_contains("coach_langs", F.col("cust_language")))))

@dlt.table(comment="Compatibility violations quarantined for CRM review, never silently fixed")
def call_attempts_quarantine():
    return dlt.read("call_attempts").filter(~F.col("compat_ok"))

# ---------------------------------------------------------------- engagement events
@dlt.table(comment="Deduped engagement events; events before signup dropped")
@dlt.expect_or_drop("after_signup", "event_timestamp >= signup_date")
def engagement_events():
    e = dlt.read_stream("bronze_engagement_events").dropDuplicates(["customer_id", "event_timestamp", "event_type"])
    return e.join(dlt.read("bronze_customers").select("customer_id", "signup_date"), "customer_id", "left")

@dlt.table(comment="Table-level drift check: share of events between 00:00 and 05:59 should stay small")
@dlt.expect("night_share_small", "night_share < 0.05")
def engagement_events_daily_dq():
    e = dlt.read("engagement_events")
    return (e.groupBy(F.to_date("event_timestamp").alias("d"))
             .agg((F.sum((F.hour("event_timestamp") < 6).cast("int")) / F.count("*")).alias("night_share")))

# ---------------------------------------------------------------- tickets
@dlt.table(comment="Tickets with enum enforcement and date-precision flag on opened_at")
@dlt.expect_or_drop("valid_category", "category IN ('medical','order','product','billing','app_tech','other')")
@dlt.expect_or_drop("valid_severity", "severity IN ('low','medium','high','urgent')")
def tickets():
    return (dlt.read("bronze_tickets")
              .withColumn("opened_at_date_precision", F.hour("opened_at") == 0)
              .withColumn("resolution_days", F.datediff("resolved_at", "opened_at")))

@dlt.table(comment="Open-ticket backlog vs trailing 30-day median; would have paged on the Nov-2025 spike")
@dlt.expect("backlog_within_band", "open_backlog < 1.5 * median_30d")
def tickets_backlog_dq():
    t = dlt.read("tickets")
    daily = t.groupBy(F.to_date("opened_at").alias("d")).agg(F.sum(F.col("resolved_at").isNull().cast("int")).alias("open_backlog"))
    w = W.orderBy("d").rowsBetween(-30, -1)
    return daily.withColumn("median_30d", F.expr("percentile_approx(open_backlog, 0.5)").over(w))

# ---------------------------------------------------------------- slots
@dlt.table(comment="Slot bookings; completed slots must link to a call")
@dlt.expect("completed_has_call", "status != 'completed' OR linked_call_id IS NOT NULL")   # 92% today
def slot_bookings():
    return dlt.read("bronze_slot_bookings")

# ---------------------------------------------------------------- coaches -> capacity fact
@dlt.table(comment="Active roster and callable capacity by language x gender pool")
@dlt.expect_or_fail("has_language", "size(coach_langs) > 0")
def coach_capacity():
    co = (dlt.read("bronze_coaches").filter("active_flag = 1")
            .withColumn("coach_langs", F.split("languages", r"\|")))
    # 1 coach ≈ 6.5 h of talk time ≈ 6.5*3600/avg_call_duration attempts; shared across the coach's languages
    exploded = co.withColumn("language", F.explode("coach_langs")).withColumn("gender", F.explode(
        F.when(F.col("gender_handled") == "Both", F.array(F.lit("M"), F.lit("F"))).otherwise(F.array("gender_handled"))))
    return exploded.groupBy("language", "gender", "team").agg(
        F.count("*").alias("coaches"),
        F.sum(F.lit(6.5 * 3600) / F.col("avg_call_duration_sec") / F.size("coach_langs")).alias("attempt_capacity_per_day"))

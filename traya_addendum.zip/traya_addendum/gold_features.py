"""Gold layer: point-in-time feature tables registered in Unity Catalog Feature Store.
Mirrors src/pipeline.py::build_decision_table in Spark, with timestamp keys so training and
daily scoring share one lookup. Databricks only; included to show the shape."""
from databricks.feature_engineering import FeatureEngineeringClient, FeatureLookup
from pyspark.sql import functions as F, Window as W

fe = FeatureEngineeringClient()
CAT = "traya"

def decision_features(spark, as_of):
    """One row per (customer_id, order_number) with as_of_date = as_of. Every window ends at as_of (exclusive)."""
    o = spark.table(f"{CAT}.silver.orders").filter(F.col("delivery_date") + F.expr("INTERVAL 7 DAYS") <= as_of)
    base = o.select("customer_id", "order_number", "order_date", "delivery_date", "channel", "kit_value_inr", "days_since_prev_order") \
            .withColumn("as_of_date", F.lit(as_of))
    e = spark.table(f"{CAT}.silver.engagement_events").filter(F.col("event_timestamp") < as_of)
    def win(days, prefix):
        w = e.filter(F.col("event_timestamp") >= F.date_sub(F.lit(as_of), days))
        return (w.groupBy("customer_id").agg(
            F.count("*").alias(f"{prefix}_total"),
            F.sum(F.col("event_type").isin("log_med_morning", "log_med_evening").cast("int")).alias(f"{prefix}_med"),
            F.sum((F.col("event_type") == "app_session_short").cast("int")).alias(f"{prefix}_app_session_short"),
            F.sum((F.col("event_type") == "whatsapp_click").cast("int")).alias(f"{prefix}_whatsapp_click"),
            F.countDistinct(F.to_date("event_timestamp")).alias(f"{prefix}_active_days")))
    ev14, ev30 = win(14, "ev14"), win(30, "ev30")
    # trend: 14d medicine logs vs the previous 14d (the first production addition)
    prev14 = (e.filter((F.col("event_timestamp") >= F.date_sub(F.lit(as_of), 28)) & (F.col("event_timestamp") < F.date_sub(F.lit(as_of), 14)))
                .groupBy("customer_id").agg(F.sum(F.col("event_type").isin("log_med_morning", "log_med_evening").cast("int")).alias("ev_prev14_med")))
    t = spark.table(f"{CAT}.silver.tickets").filter(F.col("opened_at") < as_of)
    tk = t.groupBy("customer_id").agg(
        F.sum((F.col("opened_at") >= F.date_sub(F.lit(as_of), 30)).cast("int")).alias("tk30"),
        F.sum(((F.col("opened_at") >= F.date_sub(F.lit(as_of), 30)) & F.col("severity").isin("high", "urgent")).cast("int")).alias("tk30_hi"),
        F.sum((F.col("resolved_at").isNull() | (F.col("resolved_at") > as_of)).cast("int")).alias("tk_open"),
        F.count("*").alias("tk_life"))
    ch = spark.table(f"{CAT}.silver.call_attempts").filter(F.col("attempt_time_local") < as_of)
    calls = ch.groupBy("customer_id").agg(
        F.count("*").alias("calls_hist"), F.sum(F.col("is_connected").cast("int")).alias("conn_hist"),
        F.sum((F.col("attempt_number") == 3).cast("int")).alias("att3_hist"),
        F.max("attempt_time_local").alias("last_call"))
    s = spark.table(f"{CAT}.silver.slot_bookings")
    slots = s.filter((F.col("booked_at") < as_of) & (F.col("scheduled_at") >= as_of)).groupBy("customer_id").agg(
        F.count("*").alias("slot_pending"), F.sum((F.col("booked_by") == "customer").cast("int")).alias("slot_cust_pending"))
    df = base
    for f in (ev14, ev30, prev14, tk, calls, slots):
        df = df.join(f, "customer_id", "left")
    df = (df.na.fill(0, [c for c in df.columns if c.startswith(("ev", "tk", "calls_", "conn_", "att3", "slot"))])
            .withColumn("conn_rate_hist", (F.col("conn_hist") + 0.72 * 3) / (F.col("calls_hist") + 3))
            .withColumn("med_trend_14d", F.col("ev14_med") - F.col("ev_prev14_med"))
            .withColumn("tenure_days", F.datediff(F.lit(as_of), F.col("order_date")))
            .withColumn("days_since_last_call", F.coalesce(F.datediff(F.lit(as_of), "last_call"), F.lit(999))).drop("last_call"))
    return df

def register(spark, df):
    fe.create_table(name=f"{CAT}.gold.decision_features", primary_keys=["customer_id", "order_number"],
                    timestamp_keys=["as_of_date"], df=df, description="Point-in-time features for call prioritisation")

def training_set(spark, labels_df):
    """labels_df: customer_id, order_number, as_of_date, y. The Feature Store does the as-of join."""
    lookups = [FeatureLookup(table_name=f"{CAT}.gold.decision_features", lookup_key=["customer_id", "order_number"],
                             timestamp_lookup_key="as_of_date")]
    return fe.create_training_set(df=labels_df, feature_lookups=lookups, label="y")

def score_today(spark, model_uri, candidates_df):
    """Same lookup path as training -> no train/serve skew."""
    return fe.score_batch(model_uri=model_uri, df=candidates_df)
